// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

import android.animation.Animator;
import android.view.View;

final class f
    implements android.animation.Animator.AnimatorListener
{

    private View a;
    private e b;

    f(e e1, View view)
    {
        b = e1;
        a = view;
        super();
    }

    public final void onAnimationCancel(Animator animator)
    {
        a.setVisibility(8);
        b.a = null;
    }

    public final void onAnimationEnd(Animator animator)
    {
        a.setVisibility(8);
        b.a = null;
    }

    public final void onAnimationRepeat(Animator animator)
    {
    }

    public final void onAnimationStart(Animator animator)
    {
    }
}
