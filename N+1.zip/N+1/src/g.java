// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.net.Uri;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public final class g extends WebViewClient
{

    private final Context a;
    private final h b = new h();

    public g(Context context)
    {
        a = context;
        if (a(context) && android.os.Build.VERSION.SDK_INT >= 19)
        {
            WebView.setWebContentsDebuggingEnabled(true);
        }
    }

    private static boolean a(Context context)
    {
        return (context.getApplicationInfo().flags & 2) != 0;
    }

    public final void onPageFinished(WebView webview, String s)
    {
label0:
        {
            super.onPageFinished(webview, s);
            if (a(a))
            {
                webview = String.valueOf(s);
                if (webview.length() == 0)
                {
                    break label0;
                }
                "onPageFinished url=".concat(webview);
            }
            return;
        }
        new String("onPageFinished url=");
    }

    public final void onReceivedError(WebView webview, int i, String s, String s1)
    {
        super.onReceivedError(webview, i, s, s1);
        InputStreamReader inputstreamreader;
        char ac[];
        s = new StringBuilder();
        inputstreamreader = new InputStreamReader(a.getAssets().open("html/error.html"), Charset.forName("UTF-8"));
        ac = new char[16384];
_L1:
        i = inputstreamreader.read(ac);
label0:
        {
            if (i == -1)
            {
                break label0;
            }
            try
            {
                s.append(ac, 0, i);
            }
            // Misplaced declaration of an exception variable
            catch (WebView webview)
            {
                Log.e("ci.WebClient", "Exception", webview);
                return;
            }
        }
          goto _L1
        webview.loadDataWithBaseURL("file:///android_asset/", String.format(s.toString(), new Object[] {
            s1
        }), "text/html", "UTF-8", null);
        return;
    }

    public final boolean shouldOverrideUrlLoading(WebView webview, String s)
    {
        if (!h.a(s))
        {
            return false;
        } else
        {
            a.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(s)));
            return true;
        }
    }
}
