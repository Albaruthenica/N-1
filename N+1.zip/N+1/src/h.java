// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class h
{

    private static final Pattern a[] = {
        Pattern.compile("^https://www\\.google\\.(ac|ad|ae|af|ag|al|am|as|at|az|ba|be|bf|bg|bi|bj|bs|bt|by|ca|cat|cc|cd|cf|cg|ch|ci|cl|cm|co\\.ao|co\\.bw|co\\.ck|co\\.cr|co\\.hu|co\\.id|co\\.il|co\\.im|co\\.in|co\\.je|co\\.jp|co\\.ke|co\\.kr|co\\.ls|co\\.ma|co\\.mz|co\\.nz|co\\.th|co\\.tz|co\\.ug|co\\.uk|co\\.uz|co\\.ve|co\\.vi|co\\.za|co\\.zm|co\\.zw|com|com\\.af|com\\.ag|com\\.ai|com\\.ar|com\\.au|com\\.bd|com\\.bh|com\\.bn|com\\.bo|com\\.br|com\\.by|com\\.bz|com\\.co|com\\.cu|com\\.cy|com\\.do|com\\.ec|com\\.eg|com\\.et|com\\.fj|com\\.ge|com\\.gh|com\\.gi|com\\.gr|com\\.gt|com\\.hk|com\\.iq|com\\.jo|com\\.jm|com\\.kh|com\\.kw|com\\.kz|com\\.lb|com\\.ly|com\\.mm|com\\.mt|com\\.mx|com\\.my|com\\.na|com\\.nf|com\\.ng|com\\.ni|com\\.np|com\\.nr|com\\.om|com\\.pa|com\\.pe|com\\.pg|com\\.ph|com\\.pk|com\\.pl|com\\.pr|com\\.py|com\\.qa|com\\.ru|com\\.sa|com\\.sb|com\\.sg|com\\.sl|com\\.sv|com\\.tj|com\\.tn|com\\.tr|com\\.tw|com\\.ua|com\\.uy|com\\.vc|com\\.ve|com\\.vn|cv|cz|de|dj|dk|dm|dz|ee|es|eus|fi|fm|fr|ga|gal|ge|gg|gl|gm|gp|gr|gy|hk|hn|hr|ht|hu|ie|im|info|iq|ir|is|it|it\\.ao|je|jo|jp|kg|ki|kz|la|li|lk|lt|lu|lv|md|me|mg|mk|ml|mn|ms|mu|mv|mw|ne|ne\\.jp|net|ng|nl|no|nr|nu|off\\.ai|pk|pl|pn|ps|pt|ro|rs|ru|rw|sc|se|sh|si|sk|sm|sn|so|sr|st|td|tg|tk|tl|tm|tn|to|tp|tt|us|uz|vg|vu|ws|cn|com\\.cn)/(accounts|culturalinstitute|tools).*", 66), Pattern.compile("^https://cultural\\.sandbox\\.google\\.com/.*", 66), Pattern.compile("^https://accounts\\.google\\.(ac|ad|ae|af|ag|al|am|as|at|az|ba|be|bf|bg|bi|bj|bs|bt|by|ca|cat|cc|cd|cf|cg|ch|ci|cl|cm|co\\.ao|co\\.bw|co\\.ck|co\\.cr|co\\.hu|co\\.id|co\\.il|co\\.im|co\\.in|co\\.je|co\\.jp|co\\.ke|co\\.kr|co\\.ls|co\\.ma|co\\.mz|co\\.nz|co\\.th|co\\.tz|co\\.ug|co\\.uk|co\\.uz|co\\.ve|co\\.vi|co\\.za|co\\.zm|co\\.zw|com|com\\.af|com\\.ag|com\\.ai|com\\.ar|com\\.au|com\\.bd|com\\.bh|com\\.bn|com\\.bo|com\\.br|com\\.by|com\\.bz|com\\.co|com\\.cu|com\\.cy|com\\.do|com\\.ec|com\\.eg|com\\.et|com\\.fj|com\\.ge|com\\.gh|com\\.gi|com\\.gr|com\\.gt|com\\.hk|com\\.iq|com\\.jo|com\\.jm|com\\.kh|com\\.kw|com\\.kz|com\\.lb|com\\.ly|com\\.mm|com\\.mt|com\\.mx|com\\.my|com\\.na|com\\.nf|com\\.ng|com\\.ni|com\\.np|com\\.nr|com\\.om|com\\.pa|com\\.pe|com\\.pg|com\\.ph|com\\.pk|com\\.pl|com\\.pr|com\\.py|com\\.qa|com\\.ru|com\\.sa|com\\.sb|com\\.sg|com\\.sl|com\\.sv|com\\.tj|com\\.tn|com\\.tr|com\\.tw|com\\.ua|com\\.uy|com\\.vc|com\\.ve|com\\.vn|cv|cz|de|dj|dk|dm|dz|ee|es|eus|fi|fm|fr|ga|gal|ge|gg|gl|gm|gp|gr|gy|hk|hn|hr|ht|hu|ie|im|info|iq|ir|is|it|it\\.ao|je|jo|jp|kg|ki|kz|la|li|lk|lt|lu|lv|md|me|mg|mk|ml|mn|ms|mu|mv|mw|ne|ne\\.jp|net|ng|nl|no|nr|nu|off\\.ai|pk|pl|pn|ps|pt|ro|rs|ru|rw|sc|se|sh|si|sk|sm|sn|so|sr|st|td|tg|tk|tl|tm|tn|to|tp|tt|us|uz|vg|vu|ws|cn|com\\.cn)/.*", 66)
    };

    public h()
    {
    }

    public static boolean a(String s)
    {
        Pattern apattern[] = a;
        int j = apattern.length;
        for (int i = 0; i < j; i++)
        {
            if (apattern[i].matcher(s).matches())
            {
                return false;
            }
        }

        return true;
    }

}
