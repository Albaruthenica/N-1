// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.content.Context;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public final class e extends WebChromeClient
{

    AnimatorSet a;

    public e(Context context, View view)
    {
        a = (AnimatorSet)AnimatorInflater.loadAnimator(context, b.a);
        a.setTarget(view);
        a.addListener(new f(this, view));
    }

    public final void onProgressChanged(WebView webview, int i)
    {
        super.onProgressChanged(webview, i);
        if (i == 100 && a != null && !a.isStarted())
        {
            a.start();
        }
    }
}
