// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.wNplus1;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieSyncManager;
import android.webkit.HttpAuthHandler;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.google.android.gcm.GCMRegistrar;
import com.wNplus1.ads.AdsLoader;
import com.wNplus1.ads.BottomBannerLayout;
import com.wNplus1.ads.FullscreenBanner.AdMobFSBannerController;
import com.wNplus1.ads.FullscreenBanner.FullScreenBannerController;
import com.wNplus1.ads.FullscreenBanner.IFullScreenBannerListener;
import com.wNplus1.ads.behavior.BehaviorAcceptor;
import com.wNplus1.ads.behavior.BehaviorFactory;
import com.wNplus1.ads.behavior.BehaviorVisitor;
import com.wNplus1.configuration.WebWidgetConfiguration;
import com.wNplus1.configuration.WebWidgetConfigurationManager;
import com.wNplus1.controllers.ITabsController;
import com.wNplus1.controllers.SplashScreenController;
import com.wNplus1.controllers.WebContentController;
import com.wNplus1.controllers.WidgetsController;
import com.wNplus1.deviceidparser.DeviceIdParameters;
import com.wNplus1.deviceidparser.DeviceIdParser;
import com.wNplus1.deviceidparser.IDeviceIdParserListener;
import com.wNplus1.media.camera.AlbumStorageController;
import com.wNplus1.model.WidgetEntity;
import com.wNplus1.notification.NotificationChecker;
import com.wNplus1.pull.PullServerController;
import com.wNplus1.server.AppsGeyserServerClient;
import com.wNplus1.server.PushServerClient;
import com.wNplus1.ui.dialog.SimpleDialogs;
import com.wNplus1.ui.dialog.StartupConfirmationDialog;
import com.wNplus1.ui.menu.MenuItemsHolder;
import com.wNplus1.ui.navigationdrawer.NavigationDrawer;
import com.wNplus1.ui.navigationdrawer.NavigationDrawerHolder;
import com.wNplus1.ui.navigationwidget.NavigationWidget;
import com.wNplus1.ui.navigationwidget.TopNavigationWidget;
import com.wNplus1.ui.views.AboutDialog;
import com.wNplus1.ui.views.BrowserWebView;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// Referenced classes of package com.wNplus1:
//            Factory

public class MainNavigationActivity extends AppCompatActivity
    implements android.webkit.GeolocationPermissions.Callback, android.media.MediaPlayer.OnCompletionListener, android.media.MediaPlayer.OnErrorListener, com.wNplus1.ads.AdsLoader.AdsLoadingFinishedListener, com.wNplus1.ads.AdsLoader.HeadersReceiver, BehaviorAcceptor, IDeviceIdParserListener, IFullScreenBannerListener
{
    public static final class ApplicationMode extends Enum
    {

        private static final ApplicationMode $VALUES[];
        public static final ApplicationMode COMMON;
        public static final ApplicationMode CUSTOM;
        public static final ApplicationMode UNKNOWN;

        public static ApplicationMode valueOf(String s)
        {
            return (ApplicationMode)Enum.valueOf(com/wNplus1/MainNavigationActivity$ApplicationMode, s);
        }

        public static ApplicationMode[] values()
        {
            return (ApplicationMode[])$VALUES.clone();
        }

        static 
        {
            UNKNOWN = new ApplicationMode("UNKNOWN", 0);
            COMMON = new ApplicationMode("COMMON", 1);
            CUSTOM = new ApplicationMode("CUSTOM", 2);
            $VALUES = (new ApplicationMode[] {
                UNKNOWN, COMMON, CUSTOM
            });
        }

        private ApplicationMode(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class ApplicationState extends Enum
    {

        private static final ApplicationState $VALUES[];
        public static final ApplicationState EXITING;
        public static final ApplicationState STARTED;

        public static ApplicationState valueOf(String s)
        {
            return (ApplicationState)Enum.valueOf(com/wNplus1/MainNavigationActivity$ApplicationState, s);
        }

        public static ApplicationState[] values()
        {
            return (ApplicationState[])$VALUES.clone();
        }

        static 
        {
            STARTED = new ApplicationState("STARTED", 0);
            EXITING = new ApplicationState("EXITING", 1);
            $VALUES = (new ApplicationState[] {
                STARTED, EXITING
            });
        }

        private ApplicationState(String s, int i)
        {
            super(s, i);
        }
    }


    private static final int ACTION_TAKE_PHOTO = 2;
    public static final String ADS_SLEEP_PARAM = "adsSleep";
    public static final String APPMODE_PARAM = "applicationMode";
    public static final String BANNER_JS_PARAM = "bannerJs";
    static final android.widget.FrameLayout.LayoutParams COVER_SCREEN_GRAVITY_CENTER = new android.widget.FrameLayout.LayoutParams(-1, -1, 17);
    private static final int FILECHOOSER_RESULTCODE = 1;
    public static final String PREFS_NAME = "AppsgeyserPrefs";
    private static boolean _active = false;
    private static volatile ApplicationState applicationState;
    MainNavigationActivity _activity;
    AdMobFSBannerController _adMobFSBannerController;
    WebWidgetConfiguration _config;
    Dialog _connectionErrorDialog;
    private ApplicationMode _currentMode;
    DeviceIdParameters _deviceIdParameters;
    FullScreenBannerController _fullScreenBannerController;
    private MenuItemsHolder _menuItemsHolder;
    private NavigationDrawer _navigationDrawer;
    PushServerClient _pushClient;
    AppsGeyserServerClient _serverClient;
    SplashScreenController _splashScreenController;
    ITabsController _tabsController;
    private AdsLoader adsLoader;
    private AlbumStorageController albumStorageController;
    StartupConfirmationDialog alertDialog;
    private BottomBannerLayout bannerLayout;
    private Handler loadUrlFromIntentHandler;
    private Runnable loadUrlFromIntentRunnable;
    AboutDialog mAboutDialog;
    private LinearLayout mContentView;
    private View mCustomView;
    private android.webkit.WebChromeClient.CustomViewCallback mCustomViewCallback;
    private FrameLayout mCustomViewContainer;
    private FrameLayout mFullScreenBannerView;
    private ViewGroup mSplashScreenView;
    private ValueCallback mUploadMessage;
    private VideoView mVideo;
    private View mVideoProgressView;
    private String urlFromIntentToLoad;

    public MainNavigationActivity()
    {
        _config = null;
        _deviceIdParameters = null;
        _fullScreenBannerController = null;
        _splashScreenController = null;
        _pushClient = null;
        _currentMode = ApplicationMode.COMMON;
        loadUrlFromIntentHandler = new Handler();
        loadUrlFromIntentRunnable = new Runnable() {

            final MainNavigationActivity this$0;

            public void run()
            {
label0:
                {
                    if (urlFromIntentToLoad != null && urlFromIntentToLoad.length() > 0)
                    {
                        Object obj = _tabsController.getSelectedTab();
                        if (obj == null)
                        {
                            break label0;
                        }
                        obj = ((WebContentController) (obj)).getWebView();
                        ((WebView) (obj)).stopLoading();
                        ((WebView) (obj)).loadUrl(urlFromIntentToLoad);
                    }
                    return;
                }
                loadUrlFromIntentHandler.postDelayed(this, 500L);
            }

            
            {
                this$0 = MainNavigationActivity.this;
                super();
            }
        };
    }

    private void _applyAppTheme(WebWidgetConfiguration webwidgetconfiguration)
    {
        if (webwidgetconfiguration.getApplicationTheme() != com.wNplus1.configuration.WebWidgetConfiguration.ApplicationThemes.ACTION_BAR)
        {
            break MISSING_BLOCK_LABEL_30;
        }
        try
        {
            setTheme(0x7f060135);
            webwidgetconfiguration = getSupportActionBar();
        }
        // Misplaced declaration of an exception variable
        catch (WebWidgetConfiguration webwidgetconfiguration)
        {
            webwidgetconfiguration.printStackTrace();
            return;
        }
        if (webwidgetconfiguration == null)
        {
            break MISSING_BLOCK_LABEL_30;
        }
        webwidgetconfiguration.setElevation(0.0F);
    }

    private void _applyBehaviors(List list)
    {
        BehaviorVisitor behaviorvisitor;
        for (list = list.iterator(); list.hasNext(); bannerLayout.acceptBehavior(behaviorvisitor))
        {
            behaviorvisitor = (BehaviorVisitor)list.next();
            acceptBehavior(behaviorvisitor);
            adsLoader.acceptBehavior(behaviorvisitor);
        }

    }

    private void _closeNavigationDrawer()
    {
        if (_navigationDrawer != null)
        {
            _navigationDrawer.close();
        }
    }

    private void _hideNavigationDrawer()
    {
        if (_navigationDrawer != null)
        {
            _navigationDrawer.hide();
        }
    }

    private void _initAppContent()
    {
        _tabsController = Factory.getInstance().getTabsController();
        _tabsController.initWithTabs(Factory.getInstance().getWidgetsController());
        CookieSyncManager.createInstance(_activity);
        CookieSyncManager.getInstance().startSync();
        mAboutDialog = new AboutDialog(_activity, 0x7f060138);
    }

    private boolean _isMenuItemId(int i)
    {
        return i == 0x7f0c00b4 || i == 0x7f0c00b0 || i == 0x7f0c00b2 || i == 0x7f0c00b3 || i == 0x7f0c00b1 || i == 0x7f0c00aa || i == 0x7f0c00ab || i == 0x7f0c00ac || i == 0x7f0c00ad || i == 0x7f0c00ae || i == 0x7f0c00af;
    }

    private void _postApplyAppTheme(WebWidgetConfiguration webwidgetconfiguration)
    {
        _navigationDrawer = NavigationDrawerHolder.getNavigationDrawer(this);
        if (webwidgetconfiguration.getApplicationTheme() == com.wNplus1.configuration.WebWidgetConfiguration.ApplicationThemes.SLIDER)
        {
            _showNavigationDrawer();
            return;
        } else
        {
            _removeNavigationDrawer();
            return;
        }
    }

    private void _removeNavigationDrawer()
    {
        if (_navigationDrawer != null)
        {
            _navigationDrawer.remove();
        }
    }

    private void _showNavigationDrawer()
    {
        if (_navigationDrawer != null)
        {
            _navigationDrawer.show();
        }
    }

    private void dispatchTakePictureIntent(int i)
    {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        i;
        JVM INSTR tableswitch 2 2: default 32
    //                   2 39;
           goto _L1 _L2
_L1:
        startActivityForResult(intent, i);
        return;
_L2:
        try
        {
            File file = albumStorageController.setUpPhotoFile();
            albumStorageController.setCurrentPhotoPath(file.getAbsolutePath());
            intent.putExtra("output", Uri.fromFile(file));
        }
        catch (IOException ioexception)
        {
            ioexception.printStackTrace();
            albumStorageController.setCurrentPhotoPath(null);
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    public static ApplicationState getApplicationState()
    {
        return applicationState;
    }

    public static boolean isActive()
    {
        return _active;
    }

    public static boolean isIntentAvailable(Context context, String s)
    {
        return context.getPackageManager().queryIntentActivities(new Intent(s), 0x10000).size() > 0;
    }

    public void acceptBehavior(BehaviorVisitor behaviorvisitor)
    {
        behaviorvisitor.visit(this);
    }

    public AdMobFSBannerController getAdMobFSBannerController()
    {
        return _adMobFSBannerController;
    }

    public StartupConfirmationDialog getAlertDialog()
    {
        return alertDialog;
    }

    public BottomBannerLayout getBannerLayout()
    {
        return bannerLayout;
    }

    public WebWidgetConfiguration getConfig()
    {
        return _config;
    }

    public DeviceIdParameters getDeviceIdParameters()
    {
        return _deviceIdParameters;
    }

    public FullScreenBannerController getFullScreenBannerController()
    {
        return _fullScreenBannerController;
    }

    public PushServerClient getPushClient()
    {
        if (_pushClient == null)
        {
            _pushClient = new PushServerClient(this);
        }
        return _pushClient;
    }

    public View getVideoLoadingProgressView()
    {
        if (mVideoProgressView == null)
        {
            mVideoProgressView = LayoutInflater.from(this).inflate(0x7f030041, null);
        }
        return mVideoProgressView;
    }

    public ArrayList getWeeklyHistory()
    {
        ArrayList arraylist1 = new ArrayList();
        com.wNplus1.ui.navigationwidget.INavigationWidget inavigationwidget = Factory.getInstance().getNavigationWidget();
        ArrayList arraylist = arraylist1;
        if (inavigationwidget != null)
        {
            arraylist = arraylist1;
            if (inavigationwidget instanceof NavigationWidget)
            {
                arraylist = ((NavigationWidget)inavigationwidget).getWeeklyHistory();
            }
        }
        return arraylist;
    }

    public void invoke(String s, boolean flag, boolean flag1)
    {
    }

    public boolean isCurrentStartupAdView()
    {
        return mFullScreenBannerView.getVisibility() == 0;
    }

    public void loadPreviousApplicationMode()
    {
        int i = getSharedPreferences("AppsgeyserPrefs", 0).getInt("applicationMode", ApplicationMode.COMMON.ordinal());
        if (ApplicationMode.COMMON.ordinal() != i) goto _L2; else goto _L1
_L1:
        _currentMode = ApplicationMode.COMMON;
_L4:
        if (mAboutDialog != null)
        {
            mAboutDialog.setApplicationMode(_currentMode);
        }
        return;
_L2:
        if (ApplicationMode.CUSTOM.ordinal() == i)
        {
            _currentMode = ApplicationMode.CUSTOM;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        if (i != 1 || mUploadMessage == null)
        {
            return;
        }
        if (intent == null || j != -1)
        {
            intent = null;
        } else
        {
            intent = intent.getData();
        }
        mUploadMessage.onReceiveValue(intent);
        mUploadMessage = null;
    }

    public void onAdClosed()
    {
        if (getApplicationState().equals(ApplicationState.EXITING))
        {
            finish();
        }
    }

    public void onAdFailedToLoad()
    {
    }

    public boolean onAdHeadersReceived(Map map)
    {
        boolean flag = false;
        _applyBehaviors((new BehaviorFactory()).createPreloadBehaviors(map));
        long l = getSharedPreferences("AppsgeyserPrefs", 0).getLong("adsSleep", 0L);
        if ((new Date()).compareTo(new Date(l)) >= 0)
        {
            flag = true;
        }
        return flag;
    }

    public void onAdLoadFinished()
    {
        _applyBehaviors((new BehaviorFactory()).createPostloadBehaviors(adsLoader.getLastResponseHeaders()));
    }

    public void onCompletion(MediaPlayer mediaplayer)
    {
        mediaplayer.stop();
        onHideCustomView();
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(null);
        _activity = this;
        Factory.getInstance().Init(_activity);
        applicationState = ApplicationState.STARTED;
        bundle = WebWidgetConfigurationManager.getInstance(_activity);
        int i;
        try
        {
            _config = bundle.loadConfiguration(_activity);
            _serverClient = AppsGeyserServerClient.getInstance(_activity);
            _serverClient.SendAfterInstallInfo();
            _serverClient.SendUsageInfo();
        }
        // Misplaced declaration of an exception variable
        catch (Bundle bundle)
        {
            bundle.printStackTrace();
        }
        loadPreviousApplicationMode();
        _applyAppTheme(_config);
        setContentView(0x7f030021);
        _postApplyAppTheme(_config);
        _serverClient.GetApplicationMode();
        mContentView = (LinearLayout)findViewById(0x7f0c0070);
        if (_config.getTabsPosition() == com.wNplus1.configuration.WebWidgetConfiguration.TabsPositions.BOTTOM)
        {
            i = 0x7f030037;
        } else
        {
            i = 0x7f030036;
        }
        getLayoutInflater().inflate(i, mContentView, true);
        mContentView.setKeepScreenOn(_config.getPreventFromSleep());
        mCustomViewContainer = (FrameLayout)findViewById(0x7f0c0072);
        mFullScreenBannerView = (FrameLayout)findViewById(0x7f0c0073);
        mSplashScreenView = (ViewGroup)findViewById(0x7f0c0075);
        _splashScreenController = new SplashScreenController(mSplashScreenView, this);
        if (_config.isSplashScreenEnabled())
        {
            _splashScreenController.showSplashScreen(_config.getSplashScreenImage());
        } else
        {
            showContentView();
        }
        _adMobFSBannerController = new AdMobFSBannerController(this);
        if (!StartupConfirmationDialog.isAlreadyShown(this) && _config.isStartupConfirmationDialogEnabled())
        {
            alertDialog = new StartupConfirmationDialog(this);
            alertDialog.show();
        }
        albumStorageController = new AlbumStorageController(_config.getWidgetName());
        _initAppContent();
        DeviceIdParser.getInstance().rescan(this, this);
        (new PullServerController()).reScheduleNotification(this);
        (new NotificationChecker()).rescheduleLaunch(this);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        System.err.println("menu__onCreateOptionsMenu");
        return super.onCreateOptionsMenu((new MenuItemsHolder(_config, _currentMode, this, menu)).getMenu());
    }

    protected void onDestroy()
    {
        super.onDestroy();
        System.exit(0);
    }

    public void onDeviceIdParametersObtained(DeviceIdParameters deviceidparameters)
    {
        _deviceIdParameters = deviceidparameters;
        _fullScreenBannerController = new FullScreenBannerController(mFullScreenBannerView, this);
        _fullScreenBannerController.setFullScreenBannerListener(this);
        applicationState = ApplicationState.STARTED;
        if (_config.isSplashScreenEnabled())
        {
            (new Handler()).postDelayed(new Runnable() {

                final MainNavigationActivity this$0;

                public void run()
                {
                    _fullScreenBannerController.loadBanner();
                }

            
            {
                this$0 = MainNavigationActivity.this;
                super();
            }
            }, 1500L);
        } else
        {
            _fullScreenBannerController.loadBanner();
        }
        adsLoader = new AdsLoader();
        bannerLayout = new BottomBannerLayout();
        bannerLayout.init(this, adsLoader);
        bannerLayout.setPosition(_config.getBannerPosition());
        deviceidparameters = _serverClient.GetBannerUrl();
        adsLoader.init(deviceidparameters, this);
        adsLoader.setAdsLoadingFinishedListener(this);
        adsLoader.setHeaderReceiver(this);
        adsLoader.setBottomBannerLayout(bannerLayout);
        adsLoader.reload();
    }

    public boolean onError(MediaPlayer mediaplayer, int i, int j)
    {
        mediaplayer = new Intent("android.intent.action.VIEW");
        if (getIntent() != null)
        {
            Uri uri = getIntent().getData();
            if (uri != null)
            {
                mediaplayer.setData(uri);
                startActivity(mediaplayer);
            }
        }
        return false;
    }

    public void onHideCustomView()
    {
        if (mCustomView == null)
        {
            return;
        }
        if (mVideo != null)
        {
            mVideo.stopPlayback();
        }
        mCustomView.setVisibility(8);
        mCustomViewContainer.removeView(mCustomView);
        mCustomView = null;
        mCustomViewContainer.setVisibility(8);
        mCustomViewCallback.onCustomViewHidden();
        mContentView.setVisibility(0);
        _showNavigationDrawer();
    }

    public boolean onKeyDown(int i, KeyEvent keyevent)
    {
        if (i != 4) goto _L2; else goto _L1
_L1:
        if (_navigationDrawer != null && _navigationDrawer.isOpened())
        {
            _closeNavigationDrawer();
            return true;
        }
        if (mCustomView != null)
        {
            onHideCustomView();
            return true;
        }
        keyevent = Factory.getInstance().getNavigationWidget();
        if (keyevent != null && (keyevent instanceof TopNavigationWidget) && ((TopNavigationWidget)keyevent).isSuggestionsVisible())
        {
            ((TopNavigationWidget)keyevent).hideSuggestionsView();
            return true;
        }
        if (_tabsController.onBackKeyDown()) goto _L4; else goto _L3
_L3:
        if (!getFullScreenBannerController().isOnScreen()) goto _L6; else goto _L5
_L5:
        if (!getFullScreenBannerController().isBackKeyLocked())
        {
            getFullScreenBannerController().closeBanner();
        }
_L4:
        return true;
_L6:
        if (!getApplicationState().equals(ApplicationState.EXITING))
        {
            showCloseAppDialog();
        }
        if (true) goto _L4; else goto _L2
_L2:
        return super.onKeyDown(i, keyevent);
    }

    public boolean onKeyLongPress(int i, KeyEvent keyevent)
    {
        if (i == 4)
        {
            return true;
        } else
        {
            return super.onKeyDown(i, keyevent);
        }
    }

    public void onLoadFinished()
    {
    }

    public void onLoadStarted()
    {
    }

    protected void onNewIntent(Intent intent)
    {
        if (intent != null)
        {
            setIntent(intent);
            intent = intent.getData();
            if (intent != null)
            {
                urlFromIntentToLoad = intent.toString();
                loadUrlFromIntentHandler.post(loadUrlFromIntentRunnable);
            }
        }
    }

    public boolean onOptionsItemSelected(int i, MenuItem menuitem)
    {
        Object obj;
        boolean flag1;
        boolean flag2;
        flag1 = false;
        flag2 = true;
        obj = (NavigationWidget)Factory.getInstance().getNavigationWidget();
        i;
        JVM INSTR tableswitch 2131493034 2131493044: default 76
    //                   2131493034 373
    //                   2131493035 387
    //                   2131493036 401
    //                   2131493037 468
    //                   2131493038 482
    //                   2131493039 496
    //                   2131493040 88
    //                   2131493041 164
    //                   2131493042 105
    //                   2131493043 114
    //                   2131493044 82;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12
_L1:
        boolean flag = false;
_L14:
        return flag;
_L12:
        showCloseAppDialog();
        return true;
_L8:
        _tabsController.getSelectedTab().getWebView().reload();
        return true;
_L10:
        mAboutDialog.showDialog();
        return true;
_L11:
        menuitem = new Intent("android.intent.action.VIEW", Uri.parse((new StringBuilder()).append("market://details?id=").append(_activity.getPackageName()).toString()));
        _activity.startActivity(menuitem);
        return true;
_L9:
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        if (_config.getShareExtraLink() != null && !_config.getShareExtraLink().equals(""))
        {
            menuitem = _config.getShareExtraLink();
            obj = getResources().getString(0x7f070035);
        } else
        if (_config.getUrlOverlayState() == com.wNplus1.configuration.WebWidgetConfiguration.UrlBarStates.ENABLED)
        {
            menuitem = Factory.getInstance().getTabsController().getSelectedTab().getWebView().getUrl();
            obj = getResources().getString(0x7f070036);
        } else
        {
            menuitem = (new StringBuilder()).append(getResources().getString(0x7f070021)).append(_config.getApplicationId()).append("?").append(_config.getAffiliateString()).toString();
            obj = getResources().getString(0x7f070035);
        }
        intent.putExtra("android.intent.extra.TEXT", menuitem);
        intent.putExtra("android.intent.extra.SUBJECT", ((String) (obj)));
        startActivity(Intent.createChooser(intent, "Share using"));
        return true;
_L2:
        flag = flag2;
        if (obj != null)
        {
            ((NavigationWidget) (obj)).onClickBackButton();
            return true;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        flag = flag2;
        if (obj != null)
        {
            ((NavigationWidget) (obj)).onClickForwardButton();
            return true;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        flag = flag2;
        if (obj != null)
        {
            flag = flag2;
            if (menuitem != null)
            {
                if (!menuitem.isChecked())
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                ((NavigationWidget) (obj)).reloadWithChangedUserAgent(flag);
                flag = flag1;
                if (!menuitem.isChecked())
                {
                    flag = true;
                }
                menuitem.setChecked(flag);
                return true;
            }
        }
        continue; /* Loop/switch isn't completed */
_L5:
        flag = flag2;
        if (obj != null)
        {
            ((NavigationWidget) (obj)).onPinToHomeScreenButtonClick();
            return true;
        }
        continue; /* Loop/switch isn't completed */
_L6:
        flag = flag2;
        if (obj != null)
        {
            ((NavigationWidget) (obj)).onAddToStartPageClick();
            return true;
        }
        continue; /* Loop/switch isn't completed */
_L7:
        flag = flag2;
        if (obj != null)
        {
            ((NavigationWidget) (obj)).onHomeButtonClick();
            return true;
        }
        if (true) goto _L14; else goto _L13
_L13:
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        System.err.println("menu__onOptionsItemSelected");
        if (_isMenuItemId(menuitem.getItemId()))
        {
            return onOptionsItemSelected(menuitem.getItemId(), menuitem);
        } else
        {
            return super.onOptionsItemSelected(menuitem);
        }
    }

    protected void onPause()
    {
        super.onPause();
        _active = false;
        boolean flag = ((KeyguardManager)getSystemService("keyguard")).inKeyguardRestrictedInputMode();
        if (((TelephonyManager)getSystemService("phone")).getCallState() == 1)
        {
            pauseBrowser();
        }
        if (!flag)
        {
            pauseBrowser();
        }
    }

    protected void onPostCreate(Bundle bundle)
    {
        super.onPostCreate(bundle);
        if (_menuItemsHolder == null)
        {
            _menuItemsHolder = new MenuItemsHolder(_config, this);
        }
        if (_navigationDrawer != null)
        {
            bundle = _menuItemsHolder.getAllItems();
            _navigationDrawer.setOptions(bundle);
            _navigationDrawer.show();
        }
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        System.err.println("menu__onPrepareOptionsMenu");
        return super.onPrepareOptionsMenu(menu);
    }

    protected void onResume()
    {
        super.onResume();
        _active = true;
        Object obj = getIntent();
        if (obj != null)
        {
            obj = ((Intent) (obj)).getData();
            if (obj != null)
            {
                urlFromIntentToLoad = ((Uri) (obj)).toString();
                loadUrlFromIntentHandler.post(loadUrlFromIntentRunnable);
            }
        }
        if (!_config.getPreventFromSleep())
        {
            BrowserWebView browserwebview;
            if (_config.getPushAccount().length() == 0)
            {
                if (_config.getAppGuid().length() > 0)
                {
                    updatePushAccount();
                }
            } else
            {
                String s = GCMRegistrar.getRegistrationId(this);
                if (s != null && !"".equals(s))
                {
                    if (_pushClient == null)
                    {
                        _pushClient = new PushServerClient(this);
                    }
                    _pushClient.sendRegisteredId(s);
                } else
                {
                    registerGCM(_config.getPushAccount());
                }
            }
            browserwebview = (BrowserWebView)findViewById(0x7f0c005b);
            if (browserwebview != null)
            {
                browserwebview.resumeTimers();
            }
            CookieSyncManager.getInstance().startSync();
        }
    }

    public void onShowCustomView(View view, android.webkit.WebChromeClient.CustomViewCallback customviewcallback)
    {
        if (mCustomView != null)
        {
            customviewcallback.onCustomViewHidden();
            return;
        }
        if (view instanceof FrameLayout)
        {
            FrameLayout framelayout = (FrameLayout)view;
            if (framelayout.getFocusedChild() instanceof VideoView)
            {
                mVideo = (VideoView)framelayout.getFocusedChild();
                mVideo.setOnCompletionListener(this);
                mVideo.setOnErrorListener(this);
            }
        }
        mCustomViewContainer.addView(view, COVER_SCREEN_GRAVITY_CENTER);
        mCustomView = view;
        mCustomViewCallback = customviewcallback;
        mContentView.setVisibility(8);
        _hideNavigationDrawer();
        mCustomViewContainer.setVisibility(0);
        mCustomViewContainer.bringToFront();
    }

    protected void onStart()
    {
        super.onStart();
    }

    public void openFileChooser(ValueCallback valuecallback, String s)
    {
        mUploadMessage = valuecallback;
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        valuecallback = s;
        if (s.length() == 0)
        {
            valuecallback = "*/*";
        }
        intent.setType(valuecallback);
        startActivityForResult(Intent.createChooser(intent, "File Chooser"), 1);
    }

    public void pauseBrowser()
    {
        BrowserWebView browserwebview = (BrowserWebView)findViewById(0x7f0c005b);
        if (browserwebview != null)
        {
            if (!_adMobFSBannerController.isActive())
            {
                browserwebview.pauseTimers();
            }
            _adMobFSBannerController.setActive(false);
        }
        CookieSyncManager.getInstance().stopSync();
    }

    public void registerGCM(String s)
    {
        GCMRegistrar.register(this, new String[] {
            s
        });
    }

    public int removeHistoryItem(long l)
    {
        com.wNplus1.ui.navigationwidget.INavigationWidget inavigationwidget = Factory.getInstance().getNavigationWidget();
        if (inavigationwidget != null && (inavigationwidget instanceof NavigationWidget))
        {
            return ((NavigationWidget)inavigationwidget).removeHistoryItem(l);
        } else
        {
            return -1;
        }
    }

    public void setApplicationMode(ApplicationMode applicationmode)
    {
        if (applicationmode != ApplicationMode.UNKNOWN && _currentMode != applicationmode)
        {
            getSharedPreferences("AppsgeyserPrefs", 0).edit().putInt("applicationMode", _currentMode.ordinal()).apply();
            _currentMode = applicationmode;
        }
        if (mAboutDialog != null)
        {
            mAboutDialog.setApplicationMode(_currentMode);
        }
    }

    public void setApplicationState(ApplicationState applicationstate)
    {
        applicationState = applicationstate;
    }

    public void setDeviceIdParameters(DeviceIdParameters deviceidparameters)
    {
        _deviceIdParameters = deviceidparameters;
    }

    public void setHttpAuthUsernamePassword(WebView webview, String s, String s1, String s2, String s3)
    {
        if (webview != null)
        {
            webview.setHttpAuthUsernamePassword(s, s1, s2, s3);
        }
    }

    public void setMStartupScreenViewContainer(FrameLayout framelayout)
    {
        mFullScreenBannerView = framelayout;
    }

    public void setUrlBarVisibility(final int viewVisililityCode)
    {
        runOnUiThread(new Runnable() {

            final MainNavigationActivity this$0;
            final int val$viewVisililityCode;

            public void run()
            {
                com.wNplus1.ui.navigationwidget.INavigationWidget inavigationwidget;
label0:
                {
                    inavigationwidget = Factory.getInstance().getNavigationWidget();
                    if (inavigationwidget != null)
                    {
                        if (viewVisililityCode != 0)
                        {
                            break label0;
                        }
                        ((NavigationWidget)inavigationwidget).showAnimated();
                    }
                    return;
                }
                ((NavigationWidget)inavigationwidget).hideAnimated();
            }

            
            {
                this$0 = MainNavigationActivity.this;
                viewVisililityCode = i;
                super();
            }
        });
    }

    public void showCloseAppDialog()
    {
        SimpleDialogs.createConfirmDialog(null, getResources().getString(0x7f070048), this, new android.content.DialogInterface.OnClickListener() {

            final MainNavigationActivity this$0;

            public void onClick(DialogInterface dialoginterface, int i)
            {
                _closeNavigationDrawer();
                MainNavigationActivity.applicationState = ApplicationState.EXITING;
                if (_config.getOnExitFullscreenBannerEnabled())
                {
                    _fullScreenBannerController.loadBanner();
                    return;
                } else
                {
                    finish();
                    return;
                }
            }

            
            {
                this$0 = MainNavigationActivity.this;
                super();
            }
        }, null).show();
    }

    public void showConnectionErrorDialog()
    {
        if (_connectionErrorDialog != null)
        {
            return;
        } else
        {
            _connectionErrorDialog = new Dialog(this, 0x7f060138);
            _connectionErrorDialog.setContentView(0x7f03001d);
            ((TextView)_connectionErrorDialog.findViewById(0x7f0c0064)).setText(getResources().getString(0x7f070034));
            Button button = (Button)_connectionErrorDialog.findViewById(0x7f0c0065);
            button.setText("Try Again");
            button.setOnClickListener(new android.view.View.OnClickListener() {

                final MainNavigationActivity this$0;

                public void onClick(View view)
                {
                    _tabsController = Factory.getInstance().getTabsController();
                    _tabsController.initWithTabs(Factory.getInstance().getWidgetsController());
                    _connectionErrorDialog.dismiss();
                    _connectionErrorDialog = null;
                }

            
            {
                this$0 = MainNavigationActivity.this;
                super();
            }
            });
            button = (Button)_connectionErrorDialog.findViewById(0x7f0c0066);
            button.setText("Exit");
            button.setOnClickListener(new android.view.View.OnClickListener() {

                final MainNavigationActivity this$0;

                public void onClick(View view)
                {
                    _connectionErrorDialog.dismiss();
                    _connectionErrorDialog = null;
                    _activity.finish();
                }

            
            {
                this$0 = MainNavigationActivity.this;
                super();
            }
            });
            _connectionErrorDialog.setCancelable(true);
            _connectionErrorDialog.show();
            return;
        }
    }

    public void showContentView()
    {
        mFullScreenBannerView.setVisibility(8);
        mContentView.setVisibility(0);
        mSplashScreenView.setVisibility(8);
        mContentView.bringToFront();
        _showNavigationDrawer();
    }

    public void showFullscreenBannerView()
    {
        mContentView.setVisibility(8);
        mFullScreenBannerView.setVisibility(0);
        mSplashScreenView.setVisibility(8);
        mFullScreenBannerView.bringToFront();
        _hideNavigationDrawer();
    }

    public void showHttpAuthentication(final WebView webView, final HttpAuthHandler handler, final String host, final String realm, String s, String s1, String s2, 
            int i)
    {
        if (getResources().getBoolean(0x7f080008))
        {
            s = _config.getHttpAccessLogin();
            s1 = _config.getHttpAccessPassword();
            setHttpAuthUsernamePassword(webView, host, realm, s, s1);
            handler.proceed(s, s1);
            return;
        }
        final View v = LayoutInflater.from(this).inflate(0x7f03001f, null);
        if (s1 != null)
        {
            ((EditText)v.findViewById(0x7f0c006a)).setText(s1);
        }
        if (s2 != null)
        {
            ((EditText)v.findViewById(0x7f0c006c)).setText(s2);
        }
        s1 = s;
        if (s == null)
        {
            s1 = getText(0x7f07004c).toString().replace("%s1", host).replace("%s2", realm);
        }
        webView = (new android.app.AlertDialog.Builder(this)).setTitle(s1).setView(v).setPositiveButton("Sign in", new android.content.DialogInterface.OnClickListener() {

            final MainNavigationActivity this$0;
            final HttpAuthHandler val$handler;
            final String val$host;
            final String val$realm;
            final View val$v;
            final WebView val$webView;

            public void onClick(DialogInterface dialoginterface, int j)
            {
                dialoginterface = ((EditText)v.findViewById(0x7f0c006a)).getText().toString();
                String s3 = ((EditText)v.findViewById(0x7f0c006c)).getText().toString();
                setHttpAuthUsernamePassword(webView, host, realm, dialoginterface, s3);
                handler.proceed(dialoginterface, s3);
            }

            
            {
                this$0 = MainNavigationActivity.this;
                v = view;
                webView = webview;
                host = s;
                realm = s1;
                handler = httpauthhandler;
                super();
            }
        }).setNegativeButton("Cancel", new android.content.DialogInterface.OnClickListener() {

            final MainNavigationActivity this$0;
            final HttpAuthHandler val$handler;

            public void onClick(DialogInterface dialoginterface, int j)
            {
                handler.cancel();
            }

            
            {
                this$0 = MainNavigationActivity.this;
                handler = httpauthhandler;
                super();
            }
        }).setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {

            final MainNavigationActivity this$0;
            final HttpAuthHandler val$handler;

            public void onCancel(DialogInterface dialoginterface)
            {
                handler.cancel();
            }

            
            {
                this$0 = MainNavigationActivity.this;
                handler = httpauthhandler;
                super();
            }
        }).create();
        webView.getWindow().setSoftInputMode(4);
        webView.show();
        if (i != 0)
        {
            webView.findViewById(i).requestFocus();
            return;
        } else
        {
            v.findViewById(0x7f0c006a).requestFocus();
            return;
        }
    }

    public void showMessage(String s)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(_activity);
        builder.setMessage(s);
        builder.setPositiveButton("ok", new android.content.DialogInterface.OnClickListener() {

            final MainNavigationActivity this$0;

            public void onClick(DialogInterface dialoginterface, int i)
            {
            }

            
            {
                this$0 = MainNavigationActivity.this;
                super();
            }
        });
        builder.create().show();
    }

    public void showPausedContentInfo()
    {
        if (_tabsController == null)
        {
            _tabsController = Factory.getInstance().getTabsController();
        }
        WidgetsController widgetscontroller = Factory.getInstance().getWidgetsController();
        widgetscontroller.removeAll();
        widgetscontroller.addWidget(WidgetEntity.createDefaultWidget(com.wNplus1.model.WidgetEntity.DefaultWidgetType.PAUSED));
        _tabsController.initWithTabs(widgetscontroller);
    }

    public void showSplashScreen()
    {
        mContentView.setVisibility(8);
        mFullScreenBannerView.setVisibility(8);
        mSplashScreenView.setVisibility(0);
        mSplashScreenView.bringToFront();
        _hideNavigationDrawer();
    }

    public void showVideoView()
    {
        mContentView.setVisibility(8);
        mFullScreenBannerView.setVisibility(8);
        mSplashScreenView.setVisibility(8);
        _hideNavigationDrawer();
    }

    public void updatePushAccount()
    {
        if (_pushClient == null)
        {
            _pushClient = new PushServerClient(this);
        }
        _pushClient.loadPushAccount();
    }






/*
    static ApplicationState access$302(ApplicationState applicationstate)
    {
        applicationState = applicationstate;
        return applicationstate;
    }

*/
}
